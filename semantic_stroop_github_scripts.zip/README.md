# Semantic Stroop — Cognitive Subtraction vs Conjunction

MATLAB analysis scripts for the Cognitive Neuroscience Research Studio **T1-P1** project based on Sulpizio, Spinelli & Scaltritti (2024).

## What is included

| File | Function |
| --- | --- |
| `01_Figure_A_Reproduction.m` | Reproduces published mean semantic interference and participant-level interference distribution from the published Experiment 2A/2B dataset. |
| `02_Data_Cleaning_and_Summary.m` | Imports the 20 student-collected single-task PsychoPy CSV files, filters trials, and computes participant-level mean RTs, accuracy, and subtraction scores. |
| `03_Figure_B_Exclusion_Audit.m` | Charts condition-wise RT exclusion percentages using final experimental data. |
| `04_Figure_C_Results.m` | Creates clean participant-level RT, accuracy, and interference figures. |
| `05_Exploratory_Delta_Plot.m` | Optional exploratory delta-plot analysis of the published data; **not** the required Figure A. |

The `.m` files are **cleaned-up reconstructions of the workflow**, not verbatim Command Window history exports. They were cross-checked against the published dataset and the analysis steps used in the project. They should be run in MATLAB with the source datasets before claiming end-to-end reproducibility. No Statistics and Machine Learning Toolbox is needed for these MATLAB summaries/plots.

## How to run

1. Download the original authors' publicly accessible `data_20221028_reduced.csv` and run **`01_Figure_A_Reproduction.m`**. Choose the CSV when prompted; it uses semicolons as delimiters. The script should report **89 retained participants**, approximately **652.59/661.76 ms** (single task: control/semantic), and **774.67/777.33 ms** (dual task: control/semantic). The participant-level mean interference values are approximately **9.08** and **3.62 ms**, respectively.
2. Put only the **20 final single-task participant CSVs** in a separate local folder. Do **not** mix in practice-only files, dual-task data, pilot runs, or previously exported summaries. Run **`02_Data_Cleaning_and_Summary.m`** and select that folder. It checks that each participant has 384 experimental trials.
3. In the **same MATLAB session**, run **`03_Figure_B_Exclusion_Audit.m`** and **`04_Figure_C_Results.m`**. Output PNGs and summary CSVs are written to the selected participant-data folder.
4. If desired, after running Script 01, run **`05_Exploratory_Delta_Plot.m`** in the same session.

**IMPORTANT:** Script 01 uses `clearvars`, so if you run it between Scripts 02–04 you must rerun Script 02 to restore `mainData`, `rtData`, and `summaryData`.

## Trial selection and analysis

- Published reproduction: experimental rows only; exclude two extremely low-accuracy main-task participants from 91, leaving 89; correct responses and RT >= 200 ms. The earlier pre-main-sample exclusion described by the paper is not visible in this reduced main-task dataset.
- New behavioural extension: 20 participants × 384 trials = **7,680** main-task trials. Practice and transition rows are excluded. RT analysis includes correct responses with RT >= 200 ms; **6,944** valid RT trials and **736** exclusions were reported in the project workflow.
- Accuracy is computed over *all* main experimental trials, including errors and timeouts.
- Score definitions: interference = incongruent − control; facilitation = control − congruent; overall congruency = incongruent − congruent (participant mean RTs, in ms).

## Published findings and student results

Student-sample mean RTs (congruent/control/incongruent): **675.58 / 702.10 / 746.79 ms**. Accuracies: **92.66 / 91.33 / 87.50%**. Mean interference: **44.69 ms**. These are reported from the original analysis and require the private participant CSVs to reproduce.

Repeated-measures ANOVAs and Holm-adjusted pairwise tests were performed using **JASP**, not these MATLAB scripts. The `.jasp` results file should be retained separately if available.

## Data and privacy

The **20 participants' raw PsychoPy CSV files are deliberately not included**. They may contain participant IDs and session metadata; retain them securely and share only under appropriate consent and institutional guidance. The public published-data source is obtained separately. If you share aggregate or participant-level derived summaries, ensure they are appropriately de-identified and permitted.

## Key limitations

This three-condition single-task experiment is a **modification** of the original two-condition semantic Stroop paradigm. RT subtraction estimates may reflect semantic associations, response selection, lexical differences, and unequal exclusions. The **Figure B audit uses final data**; it should not be described as an initial pilot result.

## Citation

Sulpizio, S., Spinelli, G., & Scaltritti, M. (2024). *Semantic Stroop interference is modulated by the availability of executive resources: Insights from delta-plot analyses and cognitive load manipulation*. *Memory & Cognition*, 52, 1422–1438.
