%% FIGURE B - Data-quality audit of RT exclusions
% Run 02_Data_Cleaning_and_Summary.m first in the SAME MATLAB session.
assert(exist('mainData','var')==1 && exist('rtData','var')==1, ...
    'Run 02_Data_Cleaning_and_Summary.m first.');
conditions=["congruent","control","incongruent"];
totalTrials=zeros(3,1);validTrials=zeros(3,1);
for c=1:3
    totalTrials(c)=sum(mainData.condition==conditions(c));
    validTrials(c)=sum(rtData.condition==conditions(c));
end
excludedTrials=totalTrials-validTrials;
exclusionPercent=100*excludedTrials./totalTrials;
auditTable=table(conditions',totalTrials,validTrials,excludedTrials,exclusionPercent, ...
    'VariableNames',{'Condition','Total','Valid','Excluded','ExcludedPercent'});
disp(auditTable);
writetable(auditTable,fullfile(folder,'Figure_B_Exclusion_Audit_Table.csv'));

fig=figure('Color','w','Position',[100 100 850 500]); hold on;
bar(1:3,exclusionPercent,0.55,'FaceColor',[0.45 0.65 0.78],'EdgeColor','none');
for c=1:3
    text(c,exclusionPercent(c)+0.4,sprintf('%.2f%%',exclusionPercent(c)), ...
        'HorizontalAlignment','center','FontSize',12,'Color','k','FontWeight','bold');
end
xticks(1:3);xticklabels({'Congruent','Control','Incongruent'});
ylabel('Excluded RT trials (%)');xlabel('Semantic Stroop condition');
title('Figure B. Reaction-Time Exclusion Audit','Color','k');
ylim([0 max(exclusionPercent)+3]);
set(gca,'Color','w','XColor','k','YColor','k','TickDir','out');box off;
exportgraphics(fig,fullfile(folder,'Figure_B_Exclusion_Audit.png'), ...
    'Resolution',300,'BackgroundColor','white');
% NOTE: This diagnostic uses FINAL data, and should not be called a pilot plot.
