%% FIGURE C - Participant-level RT, accuracy, and interference plots
% Run 02_Data_Cleaning_and_Summary.m first in SAME MATLAB session.
assert(exist('summaryData','var')==1,'Run 02_Data_Cleaning_and_Summary.m first.');
RT=[summaryData.congruentRT,summaryData.controlRT,summaryData.incongruentRT];
ACC=[summaryData.congruentAcc,summaryData.controlAcc,summaryData.incongruentAcc];
labels={'Congruent','Control','Incongruent'};
n=size(RT,1);

% Figure C panels A and B: individual points, group means, +/- SEM.
rng(42);
fig=figure('Color','w','Position',[100 100 1100 450]);
for panel=1:2
    subplot(1,2,panel);hold on;
    if panel==1
        Y=RT; mainColor=[0.15 0.35 0.55]; pointColor=[0.55 0.67 0.77];
        yLabelText='Reaction time (ms)'; panelTitle='A. Reaction Time';
    else
        Y=ACC;mainColor=[0.13 0.47 0.42];pointColor=[0.60 0.75 0.70];
        yLabelText='Accuracy (%)';panelTitle='B. Accuracy';
    end
    means=mean(Y,1);sem=std(Y,0,1)/sqrt(n);
    for c=1:3
        jitter=(rand(n,1)-0.5)*0.30;
        scatter(c+jitter,Y(:,c),35,pointColor,'filled', ...
            'MarkerFaceAlpha',0.65);
    end
    errorbar(1:3,means,sem,'LineStyle','none','Color',mainColor, ...
        'LineWidth',1.8,'CapSize',12);
    scatter(1:3,means,110,mainColor,'filled','MarkerEdgeColor','w','LineWidth',1.2);
    xlim([0.5 3.5]);xticks(1:3);xticklabels(labels);
    if panel==1
        ylim([min(Y(:))-50,max(Y(:))+50]);
    else
        ylim([max(0,min(Y(:))-5),100]);
    end
    ylabel(yLabelText);title(panelTitle,'Color','k','FontWeight','bold');
    set(gca,'Color','w','XColor','k','YColor','k','TickDir','out');box off;
end
sgtitle(sprintf('Semantic Stroop Performance (N = %d)',n),'Color','k');
exportgraphics(fig,fullfile(folder,'Figure_C_RT_Accuracy.png'), ...
    'Resolution',300,'BackgroundColor','white');

% Figure C panel C: each participant's incongruent - control subtraction.
scores=summaryData.Interference;avg=mean(scores);
fig2=figure('Color','w','Position',[100 100 950 450]);hold on;
yline(0,'--','Color',[0.55 0.55 0.55],'LineWidth',1.2);
scatter(1:n,scores,65,[0.55 0.67 0.77],'filled');
yline(avg,'-','Color',[0.15 0.35 0.55],'LineWidth',2);
xlabel('Participant');ylabel('Interference score (ms)');
title(sprintf('C. Individual Semantic Interference (N = %d)',n),'Color','k');
xticks(1:n);xlim([0.5 n+0.5]);
set(gca,'Color','w','XColor','k','YColor','k','TickDir','out');box off;
exportgraphics(fig2,fullfile(folder,'Figure_C_Interference.png'), ...
    'Resolution',300,'BackgroundColor','white');
fprintf('Mean interference: %.2f ms\n',avg);
