%% Clean and summarise student-collected semantic Stroop task data
% Runs in base MATLAB. Expected input: 20 individual, final, SINGLE-TASK
% PsychoPy CSVs. No dual-task runs and no test/repeated pilot files.
% Never publish identifiable participant files without appropriate consent.
clearvars; close all; clc;
folder = uigetdir(pwd,'Choose folder containing ONLY the 20 final participant CSV files');
if isequal(folder,0), error('No folder selected.'); end
files = dir(fullfile(folder,'*.csv'));
% Avoid re-reading this script's own outputs when rerunning.
keep = ~ismember(string({files.name}),["Semantic_Stroop_Participant_Results.csv", ...
    "Figure_B_Exclusion_Audit_Table.csv"]);
files=files(keep);
if numel(files)~=20
    error('Expected 20 participant CSV files; found %d. Remove test, duplicate and analysis CSVs.',numel(files));
end

allData=table();
for i=1:numel(files)
    T=readtable(fullfile(folder,files(i).name),'VariableNamingRule','preserve');
    required = {'condition','stroopresponse.rt','stroopresponse.corr'};
    assert(all(ismember(required,T.Properties.VariableNames)), ...
        'Missing necessary columns in %s',files(i).name);
    D=table();
    D.ParticipantID = repmat(i,height(T),1);
    D.condition = lower(strtrim(string(T.('condition'))));
    D.RT = double(T.('stroopresponse.rt'));
    D.accuracy = double(T.('stroopresponse.corr'));
    % PsychoPy stores RTs in seconds and correctness as 0 or 1.
    allData=[allData;D]; %#ok<AGROW>
end

% Practice/transition rows lack the MAIN keyboard accuracy field.
validCondition=ismember(allData.condition,["congruent","control","incongruent"]);
mainData=allData(validCondition & isfinite(allData.accuracy),:);
counts=accumarray(mainData.ParticipantID,1,[20,1]);
if any(counts ~= 384)
    error('Not every participant has 384 main trials. Counts: %s',mat2str(counts'));
end
for p=1:20
    counts3=[sum(mainData.ParticipantID==p & mainData.condition=="congruent"), ...
        sum(mainData.ParticipantID==p & mainData.condition=="control"), ...
        sum(mainData.ParticipantID==p & mainData.condition=="incongruent")];
    if any(counts3~=128)
        warning('Participant %d condition counts: %s (expected 128 each)',p,mat2str(counts3));
    end
end

% All main trials retained for accuracy; only valid correct trials for RT.
rtData=mainData(mainData.accuracy==1 & isfinite(mainData.RT) & mainData.RT>=0.2,:);
rtData.RTms=rtData.RT*1000;
fprintf('Total main trials: %d; valid RT trials: %d; excluded RT trials: %d\n', ...
    height(mainData),height(rtData),height(mainData)-height(rtData));

conditions=["congruent","control","incongruent"];
summaryData=table((1:20)','VariableNames',{'ParticipantID'});
rtMeans=nan(20,3);accMeans=nan(20,3);
for p=1:20
    for c=1:3
        maskRT=rtData.ParticipantID==p & rtData.condition==conditions(c);
        maskAcc=mainData.ParticipantID==p & mainData.condition==conditions(c);
        if any(maskRT), rtMeans(p,c)=mean(rtData.RTms(maskRT)); end
        accMeans(p,c)=100*mean(mainData.accuracy(maskAcc));
    end
end
if any(~isfinite(rtMeans),'all')
    error('At least one participant-condition has no valid RT trials.');
end
summaryData.congruentRT=rtMeans(:,1);
summaryData.controlRT=rtMeans(:,2);
summaryData.incongruentRT=rtMeans(:,3);
summaryData.congruentAcc=accMeans(:,1);
summaryData.controlAcc=accMeans(:,2);
summaryData.incongruentAcc=accMeans(:,3);
summaryData.Interference=rtMeans(:,3)-rtMeans(:,2);
summaryData.Facilitation=rtMeans(:,2)-rtMeans(:,1);
summaryData.OverallCongruency=rtMeans(:,3)-rtMeans(:,1);
writetable(summaryData,fullfile(folder,'Semantic_Stroop_Participant_Results.csv'));

fprintf('Mean RT (Congruent, Control, Incongruent): %.2f, %.2f, %.2f ms\n',mean(rtMeans,1));
fprintf('Mean Accuracy (Congruent, Control, Incongruent): %.2f, %.2f, %.2f %%\n',mean(accMeans,1));
fprintf('Mean Interference: %.2f ms\n',mean(summaryData.Interference));
% The ANOVAs and Holm pairwise tests were performed in JASP, not here.
