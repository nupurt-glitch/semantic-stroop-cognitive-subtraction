%% FIGURE A - Reproduce published semantic Stroop interference
% Sulpizio, Spinelli & Scaltritti (2024), Experiments 2A and 2B.
% Reconstructed, documented analysis script (not an original history export).
% Requires original authors' data_20221028_reduced.csv (semicolon-delimited).
% Runs in base MATLAB without Statistics and Machine Learning Toolbox.
clearvars; close all; clc;
[fileName, dataFolder] = uigetfile('*.csv', 'Select published data_20221028_reduced.csv');
if isequal(fileName,0), error('No published data file selected.'); end
published = readtable(fullfile(dataFolder,fileName), 'Delimiter',';', ...
    'VariableNamingRule','preserve');

% Keep only main experimental trials (training and practice excluded).
condition = string(published.Condition);
main = published(ismember(condition,["Control","Semantic"]),:);
participantIDs = unique(main.workeIdAMano);

% The reduced main-task dataset has 91 participants; two extremely low-
% accuracy participants are excluded, leaving the paper's final N=89.
% The additional participant excluded before this dataset's main-task
% sample cannot be recovered here. Verify exclusions against the article.
if numel(participantIDs) ~= 91
    warning('Expected 91 IDs before exclusions, observed %d. Review the dataset.',numel(participantIDs));
end
allAccuracy = nan(numel(participantIDs),1);
for i=1:numel(participantIDs)
    subset = main.workeIdAMano == participantIDs(i);
    allAccuracy(i) = mean(main.correct(subset));
end
[~, ranked] = sort(allAccuracy, 'ascend');
excludedIDs = participantIDs(ranked(1:2));
fprintf('Excluding lowest-accuracy IDs: %s\n', mat2str(excludedIDs'));
main = main(~ismember(main.workeIdAMano,excludedIDs),:);

% Correct responses and RT >= 200 ms (RT already in milliseconds).
valid = main.correct == 1 & ...
    isfinite(main.response_time_risposta_stroop_1) & ...
    main.response_time_risposta_stroop_1 >= 200;
publishedValid = main(valid,:);

% Summarise pooled trial-level RTs and participant-level subtraction scores.
tasks = ["SemanticStroop", "SemanticStroopWMLoad"];
taskLabels = {'Single task (2A)', 'Working-memory load (2B)'};
participantIDs = unique(publishedValid.workeIdAMano);
interference = nan(numel(participantIDs),2);
pooledMean = nan(2,2); % rows: tasks; columns: control, semantic
pooledN = zeros(2,2);
for t=1:2
    for c=1:2
        if c==1, cond="Control"; else, cond="Semantic"; end
        idx = string(publishedValid.Task)==tasks(t) & ...
              string(publishedValid.Condition)==cond;
        pooledMean(t,c) = mean(publishedValid.response_time_risposta_stroop_1(idx));
        pooledN(t,c) = sum(idx);
    end
    for p=1:numel(participantIDs)
        base = publishedValid.workeIdAMano==participantIDs(p) & ...
               string(publishedValid.Task)==tasks(t);
        controlRT = mean(publishedValid.response_time_risposta_stroop_1(base & ...
            string(publishedValid.Condition)=="Control"));
        semanticRT = mean(publishedValid.response_time_risposta_stroop_1(base & ...
            string(publishedValid.Condition)=="Semantic"));
        interference(p,t)=semanticRT-controlRT;
    end
end

fprintf('\nValid trials: %d | Participants: %d\n',height(publishedValid),numel(participantIDs));
for t=1:2
    fprintf('%s: Control %.2f ms (n=%d), Semantic %.2f ms (n=%d), participant mean interference %.2f ms (SD %.2f)\n', ...
        taskLabels{t},pooledMean(t,1),pooledN(t,1),pooledMean(t,2),pooledN(t,2), ...
        mean(interference(:,t)),std(interference(:,t)));
end

% Figure A: mean participant-level interference plus its distribution.
fig=figure('Color','w','Position',[100 100 1150 480]);
subplot(1,2,1); hold on;
m = mean(interference,1);
sem = std(interference,0,1)./sqrt(size(interference,1));
bar(1:2,m,0.55,'FaceColor',[0.42 0.63 0.78], 'EdgeColor','none');
errorbar(1:2,m,sem,'k','LineStyle','none','LineWidth',1.5);
xticks(1:2);xticklabels(taskLabels); ylabel('Mean interference (ms)');
title('A1. Reproduced mean semantic interference');set(gca,'Color','w');box off;
subplot(1,2,2); hold on;
rng(42);
for t=1:2
    x=t+(rand(size(interference,1),1)-0.5)*0.34;
    scatter(x,interference(:,t),20,[0.45 0.64 0.73],'filled', ...
        'MarkerFaceAlpha',0.55);
    plot(t,mean(interference(:,t)),'ko','MarkerFaceColor','k','MarkerSize',7);
end
yline(0,'--','Color',[0.55 0.55 0.55]);
xticks(1:2);xticklabels(taskLabels);ylabel('Participant interference (ms)');
title('A2. Participant-level interference distribution');
set(gca,'Color','w');box off;
exportgraphics(fig,fullfile(dataFolder,'Figure_A_Reproduced.png'), ...
    'Resolution',300,'BackgroundColor','white');

% Export numerical audit only; published participant IDs are pseudonyms.
audit = table(participantIDs,interference(:,1),interference(:,2), ...
    'VariableNames',{'PublishedParticipantID','SingleTaskInterferenceMs','DualTaskInterferenceMs'});
writetable(audit,fullfile(dataFolder,'Figure_A_Published_Participant_Interference.csv'));
