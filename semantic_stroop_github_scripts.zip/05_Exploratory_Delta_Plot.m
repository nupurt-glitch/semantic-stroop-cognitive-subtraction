%% OPTIONAL exploratory delta plot from the published data
% First run 01_Figure_A_Reproduction.m, which creates publishedValid.
% This is ADDITIONAL analysis, not a substitute for assigned Figure A.
assert(exist('publishedValid','var')==1, ...
    'Run 01_Figure_A_Reproduction.m first.');
taskNames=["SemanticStroop","SemanticStroopWMLoad"];
pIDs=unique(publishedValid.workeIdAMano);
deltas=nan(numel(pIDs),5,2);
for t=1:2
    for p=1:numel(pIDs)
        base=publishedValid.workeIdAMano==pIDs(p) & ...
            string(publishedValid.Task)==taskNames(t);
        rtControl=sort(publishedValid.response_time_risposta_stroop_1(base & ...
            string(publishedValid.Condition)=="Control"));
        rtSemantic=sort(publishedValid.response_time_risposta_stroop_1(base & ...
            string(publishedValid.Condition)=="Semantic"));
        if min(numel(rtControl),numel(rtSemantic))<5, continue; end
        for q=1:5
            i0=floor((q-1)*numel(rtControl)/5)+1;
            i1=floor(q*numel(rtControl)/5);
            j0=floor((q-1)*numel(rtSemantic)/5)+1;
            j1=floor(q*numel(rtSemantic)/5);
            deltas(p,q,t)=mean(rtSemantic(j0:j1))-mean(rtControl(i0:i1));
        end
    end
end
fig=figure('Color','w','Position',[100 100 1020 440]);
for t=1:2
    subplot(1,2,t);hold on;
    avg=squeeze(mean(deltas(:,:,t),1,'omitnan'))';
    sem=squeeze(std(deltas(:,:,t),0,1,'omitnan'))'/sqrt(numel(pIDs));
    errorbar(1:5,avg,sem,'-o','LineWidth',1.5,'MarkerFaceColor',[0.36 0.59 0.76]);
    yline(0,'--','Color',[0.6 0.6 0.6]);
    xticks(1:5);xlabel('RT quantile (fast to slow)');ylabel('Semantic minus control (ms)');
    if t==1, title('Single task');else,title('Working-memory load');end
    set(gca,'Color','w','XColor','k','YColor','k');box off;
end
sgtitle('Exploratory published-data delta plot');
exportgraphics(fig,fullfile(dataFolder,'Supplementary_Delta_Plot.png'), ...
    'Resolution',300,'BackgroundColor','white');
% Note: Paper's own quantile estimation may differ from this simple
% within-participant binned-mean method; compare before claiming reproduction.
